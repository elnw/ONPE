﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ONPE.WEB.ViewModel
{
    public class LoginViewModel
    {
        public String codigo { get; set; }
        public String Password { get; set; }

        public LoginViewModel() { }
    }
}